import os
os.chdir("/home/blesch/generative_RF/CTAB-GAN-Plus")
from model.ctabgan import CTABGAN
from model.eval.evaluation import get_utility_metrics,stat_sim,privacy_metrics
import numpy as np
import pandas as pd
import glob
os.chdir("../generative_rf/benchmark")
try:
    exec(open("benchmark_individual.py").read())
except:
    pass

exec(open("benchmark_individual.py").read())


num_exp = 5
dataset = "Adult"
fake_file_root = "Fake_Datasets"
path = "/home/blesch/generative_RF/CTAB-GAN-Plus/Real_Datasets/Adult.csv"
my_df = pd.read_csv("/home/blesch/generative_RF/CTAB-GAN-Plus/Real_Datasets/Adult.csv").iloc[1:1000,]
my_df1 = adult_train[1].iloc[1:1000,]

cat_cols = my_df1.select_dtypes(include=['object'])
for column in cat_cols:
    my_df1[column], _ = pd.factorize(my_df1[column])


synthesizer =  CTABGAN(df = my_df,
                 test_ratio = 0.20,
                 categorical_columns = ['workclass', 'education', 'marital-status', 'occupation', 'relationship', 'race', 'gender', 'native-country', 'income'], 
                 log_columns = [],
                 mixed_columns= {'capital-loss':[0.0],'capital-gain':[0.0]},
                 general_columns = ["age"],
                 non_categorical_columns = [],
                 integer_columns = ['age', 'fnlwgt','capital-gain', 'capital-loss','hours-per-week'],
                 problem_type= {"Classification": 'income'})

synthesizer =  CTABGAN(df = my_df1,
                 test_ratio = 0.20,
                 categorical_columns = ['workclass', 'education', 'marital-status', 'occupation', 'relationship', 'race', 'sex', 'native-country', 'label'], 
                 log_columns = [],
                 mixed_columns= {'capital-loss':[0.0],'capital-gain':[0.0]},
                 general_columns = ["age"],
                 non_categorical_columns = [],
                 integer_columns = ['age', 'fnlwgt','capital-gain', 'capital-loss','hours-per-week'],
                 problem_type= {"Classification": 'label'})


synthesizer.fit()
syn = synthesizer.generate_samples()


###### try for adult

# adult
adult_res = run_benchmark(training_data=adult_train, test_data=adult_test, classifiers=adult_classifiers,
metrics= adult_metrics, data_synthesizer=  {"CTGAN": CTGAN()})
pd.concat(adult_res).to_csv("CTGAN_adult.csv")

# TO DO - automize detection of categorical variables and pass list in arguments
def ctabgan_fun(real_data): 
    return CTABGAN(df = real_data,
                 test_ratio = 0.20,
                 categorical_columns = ['workclass', 'education', 'marital-status', 'occupation', 'relationship', 'race', 'sex', 'native-country', 'label'], 
                 log_columns = [],
                 mixed_columns= {'capital-loss':[0.0],'capital-gain':[0.0]},
                 general_columns = ["age"],
                 non_categorical_columns = [],
                 integer_columns = ['age', 'fnlwgt','capital-gain', 'capital-loss','hours-per-week'],
                 problem_type= {"Classification": 'label'})

def synth_data(data_train, synthesizer):
    """
    Arguments: 
    @data_train: data to learn synthesizer from
    @synthesizer: model for generating synthetic data
    Return: synthesized data of size data_train
    """
    if synthesizer == ctabgan_fun:
        syn = ctabgan_fun(real_data = data_train)
        syn.fit()
        return syn.generate_samples()
    else: 
        print("please use CTABGAN synthesizer")

adult_res = run_benchmark(training_data= adult_train_1, test_data = adult_test_1, classifiers= adult_classifiers, 
metrics= adult_metrics, data_synthesizer= {"CTABGAN+": ctabgan_fun})
pd.concat(adult_res).to_csv("CTABGAN_adult.csv")

adult_train_1 = (adult_train[1].iloc[1:10000,], adult_train[2].iloc[1:10000,])
adult_test_1 = (adult_test[1].iloc[1:5000,], adult_test[2].iloc[1:5000,])