# Invertible Tabular GANs: Killing Two Birds with OneStone for Tabular Data Synthesis(Neurips 2021)

This repository is the official implementation of [Invertible Tabular GANs](https://openreview.net/forum?id=tvDBe6K8L5o). 

![model](picture/model.png)

## 1. Requirement
- python version : Python 3.7.7
- package information : requirements.txt
- Data (Demo) : Adult and News data are automatically installed. (otherwise you can use dataset in [ctgan](https://github.com/sdv-dev/CTGAN/tree/master/examples/csv))

## 2. Train
1. train ITGAN model
    ```
    example : 'python train_itgan.py --data --random_num --GPU_NUM --emb_dim --en_dim --d_dim --d_dropout --d_leaky --layer_type --hdim_factor --nhidden --likelihood_coef --gt --dt --lt --kinetic --kinetic_every_learn'

    data: dataset name
    random_num: random_seed to use
    GPU_NUM: GPU number to use
    emb_dim: $dim(h)$
    en_dim: $n_{e(r)}$ = 2 -> "256,128", 3 -> "512,256,128" 
    d_dim: $n_d$ = 2 -> "256,256", 3 -> "256,256,256" 
    d_dropout: a
    d_leaky: b
    layer_type: $blend[M_i(z,t) = t], simblenddiv1[M_i(z,t) = sigmoid(FC(z⊕t))]$
    hdim_factor: M
    nhidden: K
    likelihood_coef: $\gamma$
    gt: $period_G$
    dt: $period_D$
    lt: $period_L$
    kinetic: kinetic regularizer coef
    kinetic_every_learn: if 0 apply kinetic regularizer every G likelihood training, else every all G training
    
    the name of a file to be saved is combination of each parameter
    ```
    All parameter (except kinetic, kinetic_every_learn) is in Appendix D.
    kinetic: 0.1 for ITGAN(Q) of census and ITGAN(Q), ITGAN(L) for cabs, 1.0 for others  
    kinetic_every_learn: 1 for census, 0 for others
    
    

## Reference
[1] Grover, A., Dhar, M., and Ermon, S. Flow-gan: Combining maximum likelihood and adversarial learning in generative models. In AAAI, 2018.  
[2] Chen, D., Yu, N., Zhang, Y., and Fritz, M. Gan-leaks: A taxonomy of membership inference attacks against generative models. In CCS, 2020.  
[3] Xu, L., Skoularidou, M., Cuesta-Infante, A., and Veeramachaneni, K. Modeling tabular data using conditional gan. In NeurIPS. 2019.  
[4] Chen, R. T. Q., Rubanova, Y., Bettencourt, J., and Duvenaud, D. K. Neural ordinary differential equations. In NeurIPS. 2018.  

## License

### 1. Non-Commercial License

Copyright ©SAMSUNG SDS. All rights reserved.

 
If the following conditions are met, you can reproduce, distribute, alter or use this software in source and binary forms, with or without modification:
1. You must use this software in source and binary forms for only non-commercial purposes.
2. Above copyright notice and the list of conditions and the following disclaimer must be included in all copies, derivative works, or portions of the software.  
3. You must not use the name of the copyright holder nor the names of its contributors to endorse or promote other software derived from this software without specific prior written permission by the copyright holder.
4. This software is protected by patent, but we grant you a patent license to make, use, sell, offer for sale, have made, and import this software and derivative works based upon this software free of charge for only non-commercial purposes. 

 
[Disclaimer] 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF SUCH COPYRIGHT HOLDER AND CONTRIBUTORS HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 

 

### 2. Commercial License

Copyright ©SAMSUNG SDS. All rights reserved.

If the following conditions are met, you can reproduce, distribute, alter or use this software in source and binary forms, with or without modification:

1. If you want to use this software for commercial purposes, please contact mj100.kim@samsung.com
2. Above copyright notice and the list of conditions and the following disclaimer must be included in all copies, derivative works, or portions of the software.  
3. You must not use the name of the copyright holder nor the names of its contributors to endorse or promote other software derived from this software without specific prior written permission by the copyright holder.
4. This is protected by patent but we grant you a patent license to make, use, sell, offer for sale, have made, and import this software and derivative works based upon this software free of charge with prior written permission by the copyright holder

[Disclaimer] 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF SUCH COPYRIGHT HOLDER AND CONTRIBUTORS HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

