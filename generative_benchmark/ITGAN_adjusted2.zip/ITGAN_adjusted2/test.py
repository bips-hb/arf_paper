import train_itgan as ITGAN
import os
import pandas as pd
from util.data import load_dataset,get_metadata
os.chdir("/home/blesch/generative_RF/generative_rf/benchmark")
try:
    exec(open("benchmark_individual.py").read())
except:
    pass

exec(open("benchmark_individual.py").read())



#data =  data.select_dtypes('object') # only categorical columns
# data =  data.select_dtypes('int') # only int columns

#from sdgym.datasets import load_dataset
#metadata = load_dataset('adult')
#from sdgym.datasets import load_tables
#tables = load_tables(metadata)
#data = tables['adult'].iloc[1:1000,]

#url = 'https://raw.githubusercontent.com/sdv-dev/CTGAN/master/examples/csv/adult.csv'
#data = pd.read_csv(url)

# prepare ITGAN model

def itgan_fun(real_data):
    # find categorical columns
    cat_cols = data.select_dtypes('object').columns.to_list()
    ord_cols = []
    arg = ITGAN.getArgs(data = real_data, cat_col = cat_cols, ord_col = ord_cols, GPU_NUM=1)
    return ITGAN.AEGANSynthesizer(**arg)


# define synthetic data generation
def synth_data(data_train, synthesizer):
    """
    Arguments: 
    @data_train: data to learn synthesizer from
    @synthesizer: model for generating synthetic data
    Return: synthesized data of size data_train
    """
    if synthesizer == itgan_fun:
        syn = itgan_fun(real_data = data_train)
        syn.fit()
        return syn.sample(data_train.shape[0])
    else: 
        print("please use ITGAN synthesizer")

#data = census_train[1].iloc[1:1000,]
#cat_cols = data.select_dtypes('object').columns.to_list()
#ord_cols = []
#arg = ITGAN.getArgs(data = data,cat_col = cat_cols,ord_col = ord_cols, GPU_NUM=1)
#model = ITGAN.AEGANSynthesizer(**arg)
#model.fit()
#synth_data = model.sample(data.shape[0])
#synth_data

ex = itgan_fun(data)
synth_data(data_train=data, synthesizer=itgan_fun)