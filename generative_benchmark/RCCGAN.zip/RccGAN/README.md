# RccGAN
Regularized Compound Conditional GAN for Large-Scale Tabular Data Synthesis
