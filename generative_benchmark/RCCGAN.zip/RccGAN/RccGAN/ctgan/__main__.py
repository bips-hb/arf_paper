import argparse
import os
os.chdir("./RccGAN/ctgan")
 
from data import read_csv, read_tsv, write_tsv
from ctgan import CTGANSynthesizer
import pandas as pd
# load demo
from demo import load_demo
ex = load_demo()

#ex["income"] = ex["income"].astype("category")
ex = ex.iloc[1:1000, ]
ex.to_csv("my_df.csv")

def _parse_args():
    parser = argparse.ArgumentParser(description='CTGAN Command Line Interface')
    parser.add_argument('-e', '--epochs', default=300, type=int,
                        help='Number of training epochs')
    parser.add_argument('-t', '--tsv', action='store_true',
                        help='Load data in TSV format instead of CSV')
    parser.add_argument('--no-header', dest='header', action='store_false',
                        help='The CSV file has no header. Discrete columns will be indices.')

    parser.add_argument('-m', '--metadata', help='Path to the metadata')
    parser.add_argument('-d', '--discrete',
                        help='Comma separated list of discrete columns without whitespaces.')
    parser.add_argument('-n', '--num-samples', type=int,
                        help='Number of rows to sample. Defaults to the training data size')

    parser.add_argument('--generator_lr', type=float, default=2e-4,
                        help='Learning rate for the generator.')
    parser.add_argument('--discriminator_lr', type=float, default=2e-4,
                        help='Learning rate for the discriminator.')

    parser.add_argument('--generator_decay', type=float, default=1e-6,
                        help='Weight decay for the generator.')
    parser.add_argument('--discriminator_decay', type=float, default=0,
                        help='Weight decay for the discriminator.')

    parser.add_argument('--embedding_dim', type=int, default=128,
                        help='Dimension of input z to the generator.')
    parser.add_argument('--generator_dim', type=str, default='256,256',
                        help='Dimension of each generator layer. '
                        'Comma separated integers with no whitespaces.')
    parser.add_argument('--discriminator_dim', type=str, default='256,256',
                        help='Dimension of each discriminator layer. '
                        'Comma separated integers with no whitespaces.')

    parser.add_argument('--batch_size', type=int, default=500,
                        help='Batch size. Must be an even number.')
    parser.add_argument('--save', default=None, type=str,
                        help='A filename to save the trained synthesizer.')
    parser.add_argument('--load', default=None, type=str,
                        help='A filename to load a trained synthesizer.')

    parser.add_argument("--sample_condition_column", default=None, type=str,
                        help="Select a discrete column name.")
    parser.add_argument("--sample_condition_column_value", default=None, type=str,
                        help="Specify the value of the selected discrete column.")

    parser.add_argument('--data', help='Path to training data')
    parser.add_argument('--output', help='Path of the output file')

    return parser.parse_args()


def main():
    #args = _parse_args()
# put only discrete columns here
    data, discrete_columns =read_csv(data_frame=ex, discrete= "workclass,education,marital-status,occupation,relationship,race,sex,native-country,income")
    # read_csv("my_df.csv", discrete = "workclass,education,marital-status,occupation,relationship,race,sex,native-country,income")
   # data, discrete_columns = read_csv("my_df.csv", discrete = "workclass")

    generator_dim = [int(x) for x in '256,256'.split(',')]
  #  print(discrete_columns)
    discriminator_dim = [int(x) for x in '256,256'.split(',')]
    model = CTGANSynthesizer(
        embedding_dim=128, generator_dim=generator_dim,
        discriminator_dim=discriminator_dim, generator_lr=2e-4,
        generator_decay=1e-6, discriminator_lr=2e-4,
        discriminator_decay=0, batch_size=500,
        epochs=300)
    model.fit(data,discrete_columns= discrete_columns)


    num_samples = len(data)

    sampled = model.sample(
        num_samples,
        None,
        None)


    sampled.to_csv("my_output.csv", index=False)


if __name__ == "__main__":
    main()

#['workclass','education','marital-status','occupation','relationship','race','sex','native-country','income']

out = pd.read_csv("my_output.csv")